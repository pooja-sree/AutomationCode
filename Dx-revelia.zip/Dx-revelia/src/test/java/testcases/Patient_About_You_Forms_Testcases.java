package testcases;

import com.rev.pagefactory.Forms;
import org.openqa.selenium.WebDriver;

public class Patient_About_You_Forms_Testcases extends Forms {

    public Patient_About_You_Forms_Testcases(WebDriver driver){
        super(driver);

    }

    public void About_You_Form(){
        Aboutyou();
    }

}

