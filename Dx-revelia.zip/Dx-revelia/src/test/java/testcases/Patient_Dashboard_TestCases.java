package testcases;

import com.rev.pagefactory.Patient_Dashboard;
import org.openqa.selenium.WebDriver;

public class Patient_Dashboard_TestCases extends Patient_Dashboard {

    public Patient_Dashboard_TestCases(WebDriver driver){
        super(driver);

    }

    public void Patient_Profile_update(){
        Patient_Profile();
    }
}
